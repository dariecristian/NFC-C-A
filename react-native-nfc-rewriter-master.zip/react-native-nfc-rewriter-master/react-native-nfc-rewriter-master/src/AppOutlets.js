import {getNewOutlet} from 'reconnect.js';

getNewOutlet(
  'androidPrompt',
  {
    visible: false,
  },
  {autoDelete: false},
);
